package f03CarSalesman;

public class Engine {

    private String model;
    private int power;
    private String displacement;
    private String efficiency;

    public Engine(String model, int power) {
        this.model = model;
        this.power = power;
        displacement = "n/a";
        efficiency ="n/a";
    }

    public Engine(String model, int power, String input) {
        this.model = model;
        this.power = power;
        if (isInteger(input)){
            this.displacement = input;
            efficiency = "n/a";
        }else{
            this.efficiency = input;
            displacement = "n/a";
        }
    }

    public Engine(String model, int power, String displacement, String efficiency) {
        this.model = model;
        this.power = power;
        this.displacement = displacement;
        this.efficiency = efficiency;
    }

    public String getModel() {
        return model;
    }

    public int getPower() {
        return power;
    }

    public String getDisplacement() {
        return displacement;
    }

    public String getEfficiency() {
        return efficiency;
    }

    public static boolean isInteger(String input) {

        return (input.charAt(0) >= '0' && input.charAt(0) <= '9');

    }


}
