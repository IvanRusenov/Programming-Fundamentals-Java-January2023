package f03CarSalesman;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());
        //Engines
        List<Engine> enginesList = new ArrayList<>();
        for (int i = 0; i < n; i++) {

            String[] input = scan.nextLine().split(" ");
            //"{Model}0 str, {Power}1 int, {Displacement}2 int, {Efficiency}3 str"

            if (input.length == 2) {

                Engine engine = new Engine(input[0], Integer.parseInt(input[1]));
                enginesList.add(engine);

            } else if (input.length == 3) {

                    Engine engine = new Engine(input[0], Integer.parseInt(input[1]), input[2]);
                    enginesList.add(engine);

            } else if (input.length == 4) {

                Engine engine = new Engine(input[0], Integer.parseInt(input[1]), input[2], input[3]);
                enginesList.add(engine);

            }

        }

        int m = Integer.parseInt(scan.nextLine());
        List<Car> cars = new ArrayList<>();

        for (int i = 0; i < m; i++) {

            String[] input = scan.nextLine().split(" ");

            if (input.length == 2) {

                for (Engine engine : enginesList) {

                    if (input[1].equals(engine.getModel())) {
                        Car car = new Car(input[0], engine);
                        cars.add(car);
                        break;
                    }

                }

            } else if (input.length == 3) {

                    for (Engine engine : enginesList) {

                        if (input[1].equals(engine.getModel())) {
                            Car car = new Car(input[0], engine, input[2]);
                            cars.add(car);
                            break;
                        }

                    }

            } else if (input.length == 4) {

                for (Engine engine : enginesList) {

                    if (input[1].equals(engine.getModel())) {
                        Car car = new Car(input[0], engine,input[2], input[3]);
                        cars.add(car);
                        break;
                    }

                }
            }

        }

        for (Car car : cars) {

            System.out.println(car.toString());

        }

    }

}
