package f04TeamworkProjects;

import java.util.ArrayList;
import java.util.List;

public class Team {

    private String name;

    private String creator;

    private List<String> members = new ArrayList<>();


    public Team( String creator, String name) {
        this.creator = creator;
        this.name = name;

    }

    public String getName() {
        return name;
    }

    public String getCreator() {
        return creator;
    }

    public List<String> getMembers() {
        return members;
    }

    public int getMembersSize(){return members.size();}

    public void setCreator(String creator) {
        this.creator = creator;
    }
}
