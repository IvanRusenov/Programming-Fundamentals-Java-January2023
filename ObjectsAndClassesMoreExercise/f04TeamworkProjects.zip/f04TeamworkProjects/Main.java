package f04TeamworkProjects;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int countTeams = Integer.parseInt(scan.nextLine());
        List<Team> teamList = new ArrayList<>();

        for (int i = 0; i < countTeams; i++) {

            String input = scan.nextLine();

            String user = input.split("-")[0];
            String teamName = input.split("-")[1];
            boolean isValid = true;

            if (isTeamExist(teamList,teamName)) {

                System.out.printf("Team %s was already created!\n", teamName);
                isValid = false;

            }

            for (Team team : teamList) {

                if (isMemberExist(team.getMembers(),user) || team.getCreator().equals(user)) {

                    System.out.printf("%s cannot create another team!\n", user);
                    isValid = false;
                    break;
                }

            }

            if (isValid) {

                Team team = new Team(user, teamName);
                teamList.add(team);

                System.out.printf("Team %s has been created by %s!\n", teamName, team.getCreator());

            }

        }

        String input = scan.nextLine();

        while (!input.equals("end of assignment")) {

            String[] wantToJoin = input.split("->");

            String member = wantToJoin[0];
            String teamName = wantToJoin[1];
            boolean isValid = true;
//////////////////////////////////////////////////////////////////////////////////////////
            //join the team

            if (isTeamExist(teamList, teamName)) {

                int index = 0;

                for (Team team : teamList) {

                    if (team.getName().equals(teamName)) {
                        index = teamList.indexOf(team);
                    }

                }

                for (Team team : teamList) {

                    if (isMemberExist(team.getMembers(), member) || team.getCreator().equals(member)) {

                        isValid = false;
                        break;
                    }
                }

                if (isValid) {
                    //if member does not exist - add
                    teamList.get(index).getMembers().add(member);

                } else {
                    //if exist
                    System.out.printf("Member %s cannot join team %s!\n", member, teamName);
                }


            } else {

                System.out.printf("Team %s does not exist!\n", teamName);

            }


            input = scan.nextLine();

        }
  ////////////////////////////////////////////////////////////////////////////////////////


        teamList.sort(Comparator.comparing(Team::getName));
        teamList.sort(Comparator.comparing(Team::getMembersSize).reversed());

        List<String> teamsToDisband = new ArrayList<>();
        for (Team team : teamList) {

            team.getMembers().sort(Comparator.comparing(String::toLowerCase));

            if (team.getMembersSize() > 0) {

                System.out.printf("%s\n", team.getName());
                System.out.printf("- %s\n", team.getCreator());


                for (String member : team.getMembers()) {
                    System.out.printf("-- %s\n", member);
                }

            } else {

                teamsToDisband.add(team.getName());
            }
        }

        System.out.println("Teams to disband:");

        teamsToDisband.sort(Comparator.comparing(String::toLowerCase));

        for (String team : teamsToDisband) {


            System.out.println(team);


        }

    }

    public static boolean isTeamExist(List<Team> teamList, String teamName) {

        for (Team team : teamList) {

            if (team.getName().equals(teamName)) {
                return true;
            }

        }
        return false;
    }

    public static boolean isMemberExist(List<String> members, String name) {

        for (String member : members) {

            if (name.equals(member)) {
                return true;
            }

        }
        return false;
    }
}
