package f01CompanyRoster;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        List<Employee> employees = new ArrayList<>();

        for (int i = 0; i < n; i++) {


            String[] input = scan.nextLine().split("\\s+");
            Employee employee = null;

            if (input.length == 4) {

                employee = new Employee(input[0], Double.parseDouble(input[1]),
                        input[2], input[3]);

            } else if (input.length == 5) {

                if (input[4].contains("@")) {

                    employee = new Employee(input[0], Double.parseDouble(input[1]),
                            input[2], input[3], input[4]);

                } else {

                    employee = new Employee(input[0], Double.parseDouble(input[1]),
                            input[2], input[3], Integer.parseInt(input[4]));
                }

            } else if (input.length == 6) {

                employee = new Employee(input[0], Double.parseDouble(input[1]),
                        input[2], input[3], input[4], Integer.parseInt(input[5]));
            }

            employees.add(employee);
        }
        List<String> departments = new ArrayList<>();

        for (Employee employee : employees) {

            String department = employee.getDepartment();

            if (!departments.contains(department)){

                departments.add(department);
            }

        }
       double maxDepSalary = 0 ;
        String maxAvgSalaryDep = "";
        for (String department:departments) {

            double departmentSalary = 0;
            int count = 0;

            for (Employee employee:employees) {

                if (employee.getDepartment().equals(department)){

                    departmentSalary += employee.getSalary();
                    count++;
                }
            }

            double avgDepSalary = departmentSalary / count;

            if (maxDepSalary < avgDepSalary){

                maxDepSalary = avgDepSalary;
                maxAvgSalaryDep = department;

            }
        }




        List<Employee> maxAvgSalaryEmployees = new ArrayList<>();

        for (Employee employee:employees) {

            if (employee.getDepartment().equals(maxAvgSalaryDep)){

                maxAvgSalaryEmployees.add(employee);

            }
        }

        maxAvgSalaryEmployees.sort(Comparator.comparing(Employee::getSalary).reversed());

        System.out.printf("Highest Average Salary: %s\n",maxAvgSalaryDep);

        for (Employee employee:maxAvgSalaryEmployees) {

            System.out.printf("%s %.2f %s %d\n",employee.getName(),employee.getSalary(),
                                                employee.getEmail(),employee.getAge());

        }

    }

}

