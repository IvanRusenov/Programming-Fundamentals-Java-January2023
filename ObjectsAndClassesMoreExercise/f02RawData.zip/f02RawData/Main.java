package f02RawData;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());
        List<Car> cars = new ArrayList<>();

        for (int i = 0; i < n; i++) {

            String[] carInfo = scan.nextLine().split(" ");

            String model = carInfo[0];

            Engine engine = new Engine(Integer.parseInt(carInfo[1]), Integer.parseInt(carInfo[2]));
            Cargo cargo = new Cargo(Integer.parseInt(carInfo[3]), carInfo[4]);

            List<Tire> tiresList = new ArrayList<>();

            for (int j = 5; j < 13; j += 2) {

                Tire tire = new Tire(Double.parseDouble(carInfo[j]), Integer.parseInt(carInfo[j + 1]));
                tiresList.add(tire);

            }

            Car car = new Car(model, engine, cargo, tiresList);

            cars.add(car);

        }

        String command = scan.nextLine();

        if (command.equals("fragile")) {

            for (Car car : cars) {

                if (car.getCargo().getType().equals(command)) {

                    for (Tire tire : car.getTiresList()) {

                        if (tire.getPressure() < 1.0) {

                            System.out.println(car.getModel());
                            break;
                        }
                    }

                }
            }

        } else if (command.equals("flamable")) {

            for (Car car : cars) {

                if (car.getCargo().getType().equals(command) && car.getEngine().getPower() > 250) {

                    System.out.println(car.getModel());
                }
            }
        }
    }
}
