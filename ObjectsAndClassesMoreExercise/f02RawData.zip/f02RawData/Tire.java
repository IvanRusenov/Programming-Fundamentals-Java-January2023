package f02RawData;

public class Tire {

    private Double pressure;
    private int age;


    public Tire(Double pressure, int age) {
        this.pressure = pressure;
        this.age = age;
    }


    public Double getPressure() {
        return pressure;
    }

    public int getAge() {
        return age;
    }
}
