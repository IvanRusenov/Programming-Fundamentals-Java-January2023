package ObjectsAndClassesExercise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        String[] input = scan.nextLine().split(",\\s+");

        Article art = new Article(input[0],input[1],input[2]);


        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {

            String data = scan.nextLine();

            if (data.split(": ")[0].equals("Edit")) {

                art.setContent(data.split(": ")[1]);

            } else if (data.split(": ")[0].equals("ChangeAuthor")) {

               art.setAuthor(data.split(": ")[1]);

            } else if (data.split(": ")[0].equals("Rename")) {

               art.setTitle(data.split(": ")[1]);

            }


        }
        System.out.printf("%s - %s: %s",art.getTitle(),art.getContent(),art.getAuthor());

    }
}
