public class Vehicle {

    //Type: {typeOfVehicle}
    private String type;
    //Model: {modelOfVehicle}
    private String model;
    //Color: {colorOfVehicle}
    private String color;
    //Horsepower: {horsepowerOfVehicle}
    private int horsePower;

    public Vehicle (String t,String m, String c, int hp){

        this.type = t;
        this.model = m;
        this.color = c;
        this.horsePower = hp;

    }

    public String getType() {
        return type;
    }

    public String getModel() {
        return model;
    }

    public String getColor() {
        return color;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setType(String type) {
        this.type = type;
    }
}
