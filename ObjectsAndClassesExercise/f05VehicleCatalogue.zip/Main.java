import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        List<Vehicle> vehicleList = new ArrayList<>();

        String input = scan.nextLine();
        while (!input.equals("End")) {

            String type = input.split(" ")[0];

            if (type.equals("car")) {
                type = "Car";
            } else {
                type = "Truck";
            }
            String model = input.split(" ")[1];
            String color = input.split(" ")[2];
            int hp = Integer.parseInt(input.split(" ")[3]);

            Vehicle vehicle = new Vehicle(type, model, color, hp);
            vehicleList.add(vehicle);

            input = scan.nextLine();

        }

        input = scan.nextLine();


        while (!input.equals("Close the Catalogue")) {

            for (Vehicle vehicle : vehicleList) {

                if (input.equals(vehicle.getModel())) {

                    System.out.println("Type: " + vehicle.getType());
                    System.out.println("Model: " + vehicle.getModel());
                    System.out.println("Color: " + vehicle.getColor());
                    System.out.println("Horsepower: " + vehicle.getHorsePower());


                }

            }

            input = scan.nextLine();
        }
        int carsHp = 0;
        int trucksHp = 0;
        int countCar = 0;
        int countTruck = 0;

        for (Vehicle vehicle : vehicleList) {

            if (vehicle.getType().equals("Car")) {
                carsHp += vehicle.getHorsePower();
                countCar++;

            } else {

                trucksHp += vehicle.getHorsePower();
                countTruck++;
            }

        }
        double avgCarsHP = 0;
        if (countCar != 0) {
            avgCarsHP = 1.0 * carsHp / countCar;
        }
        double abgTruckHP = 0;
        if (countTruck != 0) {
            abgTruckHP = 1.0 * trucksHp / countTruck;
        }
        System.out.printf("Cars have average horsepower of: %.2f.\n", avgCarsHP);
        System.out.printf("Trucks have average horsepower of: %.2f.\n", abgTruckHP);

    }
}
