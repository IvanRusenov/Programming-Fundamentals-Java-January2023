package f03OpinionPoll;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int n = Integer.parseInt(scan.nextLine());

        List<Person> persons = new ArrayList<>();

        for (int i = 0; i < n; i++) {

            String input = scan.nextLine();

            Person person = new Person(input.split(" ")[0], Integer.parseInt(input.split(" ")[1]));

            if (person.getAge() > 30){
                persons.add(person);
            }

        }
        for (Person person:persons) {

            System.out.printf("%s - %d\n",person.getName(),person.getAge());

        }
    }
}
