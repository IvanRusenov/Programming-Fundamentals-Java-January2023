package f06OrderByAge;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        String input = scan.nextLine();

        List<Person> persons = new ArrayList<>();

        while(!input.equals("End")){

            String [] data = input.split(" ");

            String name = data[0];
            String id = data[1];
            int age = Integer.parseInt(data[2]);

            Person person = new Person(name,id,age);

            persons.add(person);



            input = scan.nextLine();
        }

        persons.sort(Comparator.comparing(Person::getAge));

        for (Person person:persons) {


            System.out.printf("%s with ID: %s is %d years old.\n",person.getName(),person.getId(),person.getAge());
        }
    }
}
